from application import create_application

# Create the app using the factory method in your __init__.py
application = create_application()